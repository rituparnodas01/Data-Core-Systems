module.exports = { 
    validationErrorCode:422,
    unauthErrorCOde:401,
    notfoundErrorCode:404,
    successCode:200,
    serverErrorCode:500,
};