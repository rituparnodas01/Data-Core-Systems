let express = require('express');
let router = express.Router();
require('express-group-routes');

module.exports = router;